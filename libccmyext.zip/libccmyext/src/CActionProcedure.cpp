#include "CActionProcedure.h"
#include "CActionManager.h"

CCEActionProcedure::CCEActionProcedure(void)
{
	m_weekpManager = NULL;
	m_procedureTag = 0;
}

CCEActionProcedure::~CCEActionProcedure(void)
{
}
