#include "CActionParam.h"

CCEActionParam::CCEActionParam(int procedureID, int stepID)
{
	m_procedureID = procedureID;
	m_stepID = stepID;
}

CCEActionParam::~CCEActionParam(void)
{
}
